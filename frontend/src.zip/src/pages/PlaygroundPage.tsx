import PageShell from '../components/PageShell'
import BrowserWindow from '../components/BrowserWindow'
import FitTheLine from '../components/playground/FitTheLine'
import GuessCorrelation from '../components/playground/GuessCorrelation'
import SpamOrHam from '../components/playground/SpamOrHam'
import { useReveal } from '../hooks/useReveal'
import type { Theme } from '../hooks/useTheme'
import type { CSSProperties } from 'react'

const GAMES = [
  { id: 'fit', title: 'Train a model', tag: 'Linear regression', node: <FitTheLine /> },
  { id: 'corr', title: 'Guess the correlation', tag: 'Statistics', node: <GuessCorrelation /> },
  { id: 'spam', title: 'Spam or not spam?', tag: 'Naive Bayes · NLP', node: <SpamOrHam /> },
]

export default function PlaygroundPage({ theme, setTheme }: { theme: Theme; setTheme: (t: Theme) => void }) {
  useReveal()
  return (
    <PageShell theme={theme} setTheme={setTheme} emoji="🎮" title="Playground"
      intro="Don’t just read about data and AI, play with it. Three tiny experiments, all running live in your browser.">
      <div className="pgrid">
        {GAMES.map((g, i) => (
          <div key={g.id} className="rvz" style={{ '--d': `${i * 110}ms` } as CSSProperties}>
            <BrowserWindow className="play" label={g.title}>
              <div className="play-in">
                <h2>{g.title}</h2>
                <span className="cat">{g.tag}</span>
                {g.node}
              </div>
            </BrowserWindow>
          </div>
        ))}
      </div>
    </PageShell>
  )
}
