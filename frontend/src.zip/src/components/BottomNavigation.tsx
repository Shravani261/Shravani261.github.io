import type { CSSProperties } from 'react'
import { Link } from 'react-router-dom'
import { nav } from '../config/siteConfig'

interface Props { active: string; onSelect: (id: string) => void }

const Arrow = ({ d }: { d: string }) => (
  <svg className="arr" viewBox="0 0 60 24" fill="none" stroke="#0B2348" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true"><path d={d} /></svg>
)

export default function BottomNavigation({ active, onSelect }: Props) {
  return (
    <div className="show" id="explore" aria-label="Section shortcuts">
      <div className="bub">Hover to see the magic! ✨</div>
      <Arrow d="M2 8 Q30 24 56 14M48 6l9 8-11 3" />
      <div className="tiles">
        {nav.map(n => (
          <Link key={n.id} className="tile" to={n.to} aria-current={active === n.id ? 'page' : undefined}
             style={{ '--c': n.color, '--h': n.hover, ...(n.id === 'home' ? { color: '#fff' } : {}) } as CSSProperties}
             onClick={() => onSelect(n.id)}>{n.label}</Link>
        ))}
      </div>
      <Arrow d="M2 14 Q30 0 56 10M48 2l9 8-11 3" />
      <div className="bub">Dynamic colour change! ♡</div>
    </div>
  )
}
